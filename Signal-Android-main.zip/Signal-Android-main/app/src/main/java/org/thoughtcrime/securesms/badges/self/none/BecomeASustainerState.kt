package org.thoughtcrime.securesms.badges.self.none

import org.thoughtcrime.securesms.badges.models.Badge

data class BecomeASustainerState(
  val badge: Badge? = null
)
