package org.thoughtcrime.securesms;

public interface MasterSecretListener {
  void onMasterSecretCleared();
}
