package org.thoughtcrime.securesms.badges.self.featured

enum class SelectFeaturedBadgeEvent {
  NO_BADGE_SELECTED,
  FAILED_TO_UPDATE_PROFILE,
  SAVE_SUCCESSFUL
}
