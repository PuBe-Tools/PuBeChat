package org.thoughtcrime.securesms.badges.self.overview

enum class BadgesOverviewEvent {
  FAILED_TO_UPDATE_PROFILE
}
